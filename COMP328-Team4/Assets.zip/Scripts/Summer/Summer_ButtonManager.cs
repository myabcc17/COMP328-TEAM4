﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Summer_ButtonManager : MonoBehaviour {

    public void OnClick_Regame()
    {
        SceneManager.LoadScene(1);
    }
    public void OnClick_Exit()
    {

    }
}